

class CategoryFilter {
  String latest;
  String byname;
  CategoryFilter();
}
